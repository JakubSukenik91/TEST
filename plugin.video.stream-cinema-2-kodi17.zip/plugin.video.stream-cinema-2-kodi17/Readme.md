# Stream Cinema 2.0

Kodi plugin that all your family loves.
